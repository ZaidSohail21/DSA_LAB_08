struct Node {
	int data;
	Node* next;
	Node* prev;
};