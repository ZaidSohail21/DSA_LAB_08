//#include "myDLL.h"
//
//int main()
//{
//	myDLL obj;
//
//	obj.insertAtTail(20);
//	obj.insertAtTail(15);
//	obj.insertAtTail(99);
//	obj.insertAtHead(1024);
//	int a;
//	cout << "Enter value you wanted to delete :";
//	cin >> a;
//	obj.deleteValue(a);
//	cout << "Display :"<< endl;
//	obj.displayFromTail();
//
//	return 0;
//}