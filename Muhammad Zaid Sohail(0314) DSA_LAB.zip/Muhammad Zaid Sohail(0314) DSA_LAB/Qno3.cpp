//#include "myDLL.h"
//
//int main()
//{
//	myDLL obj;
//
//	obj.insertAtTail(20);
//	obj.insertAtTail(15);
//	obj.insertAtTail(99);
//	obj.insertAtHead(1024);
//	obj.insertAtPosition(2,1);
//	obj.deleteAtPosition(2);
//	cout << "The entered value is present(0/1):" << obj.search(15) << endl;
//	cout << "The total number of nodes " << obj.count() << endl;
//	cout << "Display :" << endl;
//	obj.displayFromHead();
//
//	return 0;
//}