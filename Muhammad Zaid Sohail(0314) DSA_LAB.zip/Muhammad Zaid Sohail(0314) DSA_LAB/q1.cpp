//#include "myDLL.h"
//
//int main()
//{
//	myDLL obj;
//
//	obj.insertAtTail(20);
//	obj.insertAtTail(15);
//	obj.insertAtTail(99);
//
//	cout << "Display From Tlai: " << endl;
//	obj.displayFromTail();
//
//	return 0;
//}